package ru.mastercond;

public class MenuOpened {
  
   boolean s;

   public boolean setMenuOpened(boolean s) 
   {
      this.s=s;
      return s;
   }
   
   public boolean getMenuOpened()     
   {       
     return s;     
   }
  
}
