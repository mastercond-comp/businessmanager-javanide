package ru.mastercond;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

public class SQLiteConnect extends SQLiteOpenHelper
{
  
    private static final int DATABASE_VERSION = 3;
  
    public static final String DATABASE_NAME="dbbusinessmanagement.db"; //имя базы данных

    //public static final String TABLE1_NAME="kontragenti"; //имя таблицы - список контрагентов (справочник)
    //public static final String TABLE2_NAME="sdelki"; //имя таблицы - список всех сделок
    //public static final String TABLE3_NAME="tovari-uslugi"; //имя таблицы - список всех товаров и услуг (прайс)
    //public static final String TABLE4_NAME="documents"; //имя таблицы - письма на бланке организации, технические заключения, акты сверки и т.д.
    //public static final String TABLE5_NAME="moi-rekviziti"; //имя таблицы - реквизиты моих организаций
    //public static final String TABLE6_NAME="settings"; //имя таблицы - настройки приложения
    //public static final String TABLE7_NAME="mysql-remote-database"; //имя таблицы - настройки для удаленного доступа к mysql (при многопользовательском режиме работы)

    //public static final String TABLE1_COL_1="ID"; //имя столбца таблицы 1
    //public static final String TABLE1_COL_2="NAME"; //имя столбца таблицы 1
    //public static final String TABLE1_COL_3="SURNAME"; //имя столбца таблицы 1
    //public static final String TABLE1_COL_4="MARKS"; //имя столбца таблицы 1

    public SQLiteConnect (Context context)
    {
        super(context,DATABASE_NAME,null,1);
        SQLiteDatabase db=this.getWritableDatabase();
        onUpgrade(db, 1, DATABASE_VERSION); //обновляем БД с версии 1 до новой версии
        onUpgrade(db, 3, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE IF NOT EXISTS MYFIRMREKVIZITI (ID Integer Primary Key Autoincrement NOT NULL, FULLNAME Varchar(255),SOKRNAME Varchar(255),INN Varchar(255),KPP Varchar(255),OGRN Varchar(255),BANKNAME Varchar(255),BANKBIK Varchar(255),BANKKS Varchar(255),BANKRS Varchar(255),RUKDOLZHN Varchar(255),VLICE Varchar(255),FIORUK Varchar(255),URADDR Varchar(255),FACTADDR Varchar(255),POSTADDR Varchar(255),PHONE Varchar(255),MOBILE Varchar(255),EMAIL Varchar(255),SITE Varchar(255));"); //SQL-запрос на создание БД
        
        db.execSQL("CREATE TABLE IF NOT EXISTS KONTRAGENTI (ID Integer Primary Key Autoincrement NOT NULL, FULLNAME Varchar(255),SOKRNAME Varchar(255),INN Varchar(255),KPP Varchar(255),OGRN Varchar(255),BANKNAME Varchar(255),BANKBIK Varchar(255),BANKKS Varchar(255),BANKRS Varchar(255),RUKDOLZHN Varchar(255),VLICE Varchar(255),FIORUK Varchar(255),URADDR Varchar(255),FACTADDR Varchar(255),POSTADDR Varchar(255),PHONE Varchar(255),MOBILE Varchar(255),EMAIL Varchar(255),SITE Varchar(255), OTVETSTVENNIJ Varchar(255));"); //SQL-запрос на создание БД
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) //действия при обновлении базы данных
    {
       if (oldVersion < 3) {
         db.execSQL("CREATE TABLE IF NOT EXISTS KONTRAGENTI (ID Integer Primary Key Autoincrement NOT NULL, FULLNAME Varchar(255),SOKRNAME Varchar(255),INN Varchar(255),KPP Varchar(255),OGRN Varchar(255),BANKNAME Varchar(255),BANKBIK Varchar(255),BANKKS Varchar(255),BANKRS Varchar(255),RUKDOLZHN Varchar(255),VLICE Varchar(255),FIORUK Varchar(255),URADDR Varchar(255),FACTADDR Varchar(255),POSTADDR Varchar(255),PHONE Varchar(255),MOBILE Varchar(255),EMAIL Varchar(255),SITE Varchar(255), OTVETSTVENNIJ Varchar(255));"); //SQL-запрос на создание БД
       }
       
       
       if (oldVersion < 4) {
         db.execSQL("CREATE TABLE IF NOT EXISTS TOVARI (ID Integer Primary Key Autoincrement NOT NULL, NAME Varchar(255),CENA Varchar(255),KOLVO Varchar(255),EDIZM Varchar(255));"); //SQL-запрос на создание БД
         
         db.execSQL("CREATE TABLE IF NOT EXISTS USLUGI (ID Integer Primary Key Autoincrement NOT NULL, NAME Varchar(255),CENA Varchar(255),KOLVO Varchar(255),EDIZM Varchar(255));"); //SQL-запрос на создание БД
         
       }
        
        if (oldVersion <= 3) {
         db.execSQL("CREATE TABLE IF NOT EXISTS SDELKI (ID Integer Primary Key Autoincrement NOT NULL, K_FULLNAME Varchar(255),K_SOKRNAME Varchar(255),K_INN Varchar(255),K_KPP Varchar(255),K_OGRN Varchar(255),K_BANKNAME Varchar(255),K_BANKBIK Varchar(255),K_BANKKS Varchar(255),K_BANKRS Varchar(255),K_RUKDOLZHN Varchar(255),K_VLICE Varchar(255),K_FIORUK Varchar(255),K_URADDR Varchar(255),K_FACTADDR Varchar(255),K_POSTADDR Varchar(255),K_PHONE Varchar(255),K_MOBILE Varchar(255),K_EMAIL Varchar(255),K_SITE Varchar(255), K_OTVETSTVENNIJ Varchar(255),MY_FULLNAME Varchar(255),MY_SOKRNAME Varchar(255),MY_INN Varchar(255),MY_KPP Varchar(255),MY_OGRN Varchar(255),MY_BANKNAME Varchar(255),MY_BANKBIK Varchar(255),MY_BANKKS Varchar(255),MY_BANKRS Varchar(255),MY_RUKDOLZHN Varchar(255),MY_VLICE Varchar(255),MY_FIORUK Varchar(255),MY_URADDR Varchar(255),MY_FACTADDR Varchar(255),MY_POSTADDR Varchar(255),MY_PHONE Varchar(255),MY_MOBILE Varchar(255),MY_EMAIL Varchar(255),MY_SITE Varchar(255), MY_USLUGIPO Varchar(10000), MY_SLOGAN Varchar(1000), MY_LOGOIMG Varchar(2000), MY_PECHATIMG Varchar(2000), NOMERSDELKI Varchar(255), KP_DATA Varchar(255),KP_SPECUSLOVIJA Varchar(10000), SCHET_DATA Varchar(255), SCHET_USLOVIJA Varchar(10000), DOGOVOR_DATA, DOGOVOR_GOROD Varchar(255), DOGOVOR_SROKIISPOLNENIJA Varchar(10000), DOGOVOR_SROKIOPLATI Varchar(10000), DOGOVOR_GARANTIJA Varchar(10000), DOGOVOR_OSOBIJEUSLOVIJA Varchar(10000), DOGOVOR_ARBITRSUD Varchar(1000), NAK1_DATA Varchar(255), NAK2_DATA Varchar(255), AKT1_DATA Varchar(255), AKT2_DATA Varchar(255), SDELKA_ENDGOD Varchar(255), SDELKA_STATUS Varchar(255), TZAKL_DATA Varchar(255), TZAKL_TEKST Varchar(10000));"); //SQL-запрос на создание БД
         
         db.execSQL("CREATE TABLE IF NOT EXISTS TOVARI_SDELKI (ID Integer Primary Key Autoincrement NOT NULL, IDD Varchar(255), NAME Varchar(255),CENA Varchar(255),KOLVO Varchar(255),EDIZM Varchar(255), NAKLADNAJA_NOMER Varchar(255) );"); //SQL-запрос на создание БД
         
         db.execSQL("CREATE TABLE IF NOT EXISTS USLUGI_SDELKI (ID Integer Primary Key Autoincrement NOT NULL, IDD Varchar(255),NAME Varchar(255),CENA Varchar(255),KOLVO Varchar(255),EDIZM Varchar(255), AKT_NOMER Varchar(255));"); //SQL-запрос на создание БД
       }
        
        
    }

    public void AddMyFirm(String MyFullName , String MySokrName, String MyINN, String MyKPP, String MyOGRN, String MyBankName, String MyBankBIK, String MyBankKS, String MyBankRS,
                          String MyRukDolzhn, String MyVlice, String MyFIOruk, String MyUrAddr, String MyFaktAddr, String MyPostAddr, String MyPhone, String MyMobile, String MyEmail, String MySite)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String id="1";
        db.execSQL("INSERT OR REPLACE INTO MYFIRMREKVIZITI ([ID],[FULLNAME],[SOKRNAME],[INN],[KPP],[OGRN],[BANKNAME],[BANKBIK],[BANKKS],[BANKRS],[RUKDOLZHN],[VLICE],[FIORUK],[URADDR],[FACTADDR],[POSTADDR],[PHONE],[MOBILE],[EMAIL],[SITE]) VALUES ('"+id+"' , '"+ MyFullName+"' , '"+ MySokrName+"', '"+MyINN+"', '"+MyKPP+"', '"+MyOGRN+"', '"+MyBankName+"', '"+MyBankBIK+"', '"+MyBankKS+"', '"+MyBankRS+"','"+MyRukDolzhn+"', '"+MyVlice+"', '"+MyFIOruk+"', '"+MyUrAddr+"', '"+MyFaktAddr+"', '"+MyPostAddr+"', '"+MyPhone+"', '"+MyMobile+"','"+MyEmail+"','"+MySite+"'); ");
    }
    
    public void AddMyFirmDB(String MyFullName , String MySokrName, String MyINN, String MyKPP, String MyOGRN, String MyBankName, String MyBankBIK, String MyBankKS, String MyBankRS,
                          String MyRukDolzhn, String MyVlice, String MyFIOruk, String MyUrAddr, String MyFaktAddr, String MyPostAddr, String MyPhone, String MyMobile, String MyEmail, String MySite)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        
        db.execSQL("INSERT OR REPLACE INTO MYFIRMREKVIZITI ([FULLNAME],[SOKRNAME],[INN],[KPP],[OGRN],[BANKNAME],[BANKBIK],[BANKKS],[BANKRS],[RUKDOLZHN],[VLICE],[FIORUK],[URADDR],[FACTADDR],[POSTADDR],[PHONE],[MOBILE],[EMAIL],[SITE]) VALUES ('"+MyFullName+"' , '"+ MySokrName+"', '"+MyINN+"', '"+MyKPP+"', '"+MyOGRN+"', '"+MyBankName+"', '"+MyBankBIK+"', '"+MyBankKS+"', '"+MyBankRS+"','"+MyRukDolzhn+"', '"+MyVlice+"', '"+MyFIOruk+"', '"+MyUrAddr+"', '"+MyFaktAddr+"', '"+MyPostAddr+"', '"+MyPhone+"', '"+MyMobile+"','"+MyEmail+"','"+MySite+"'); ");
    }
    
    
    public void ChangeMyFirm(String ID, String MyFullName , String MySokrName, String MyINN, String MyKPP, String MyOGRN, String MyBankName, String MyBankBIK, String MyBankKS, String MyBankRS,
                          String MyRukDolzhn, String MyVlice, String MyFIOruk, String MyUrAddr, String MyFaktAddr, String MyPostAddr, String MyPhone, String MyMobile, String MyEmail, String MySite)
    {
        SQLiteDatabase db = this.getWritableDatabase();
       
        db.execSQL("INSERT OR REPLACE INTO MYFIRMREKVIZITI ([ID],[FULLNAME],[SOKRNAME],[INN],[KPP],[OGRN],[BANKNAME],[BANKBIK],[BANKKS],[BANKRS],[RUKDOLZHN],[VLICE],[FIORUK],[URADDR],[FACTADDR],[POSTADDR],[PHONE],[MOBILE],[EMAIL],[SITE]) VALUES ('"+ID+"' , '"+ MyFullName+"' , '"+ MySokrName+"', '"+MyINN+"', '"+MyKPP+"', '"+MyOGRN+"', '"+MyBankName+"', '"+MyBankBIK+"', '"+MyBankKS+"', '"+MyBankRS+"','"+MyRukDolzhn+"', '"+MyVlice+"', '"+MyFIOruk+"', '"+MyUrAddr+"', '"+MyFaktAddr+"', '"+MyPostAddr+"', '"+MyPhone+"', '"+MyMobile+"','"+MyEmail+"','"+MySite+"'); ");
    }
    
    public void DelMyFirm(String ID)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        
        db.execSQL("DELETE FROM MYFIRMREKVIZITI WHERE ID=" + ID+";");
    }
    
    
    public void AddKontragent(String FullName , String SokrName, String INN, String KPP, String OGRN, String BankName, String BankBIK, String BankKS, String BankRS, String RukDolzhn, String Vlice, String FIOruk, String UrAddr, String FaktAddr, String PostAddr, String Phone, String Mobile, String Email, String Site, String Otvetstvennij)
    {

       SQLiteDatabase db =  this.getWritableDatabase();
        
        db.execSQL("INSERT OR REPLACE INTO KONTRAGENTI ([FULLNAME],[SOKRNAME],[INN],[KPP],[OGRN],[BANKNAME],[BANKBIK],[BANKKS],[BANKRS],[RUKDOLZHN],[VLICE],[FIORUK],[URADDR],[FACTADDR],[POSTADDR],[PHONE],[MOBILE],[EMAIL],[SITE], [OTVETSTVENNIJ]) VALUES ('"+FullName+"' , '"+ SokrName+"', '"+INN+"', '"+KPP+"', '"+OGRN+"', '"+BankName+"', '"+BankBIK+"', '"+BankKS+"', '"+BankRS+"','"+RukDolzhn+"', '"+Vlice+"', '"+FIOruk+"', '"+UrAddr+"', '"+FaktAddr+"', '"+PostAddr+"', '"+Phone+"', '"+Mobile+"','"+Email+"','"+Site+"','"+Otvetstvennij+"'); ");
    }
    
    public void ChangeKontragent(String ID, String FullName , String SokrName, String INN, String KPP, String OGRN, String BankName, String BankBIK, String BankKS, String BankRS, String RukDolzhn, String Vlice, String FIOruk, String UrAddr, String FaktAddr, String PostAddr, String Phone, String Mobile, String Email, String Site, String Otvetstvennij)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        
        db.execSQL("INSERT OR REPLACE INTO KONTRAGENTI ([ID],[FULLNAME],[SOKRNAME],[INN],[KPP],[OGRN],[BANKNAME],[BANKBIK],[BANKKS],[BANKRS],[RUKDOLZHN],[VLICE],[FIORUK],[URADDR],[FACTADDR],[POSTADDR],[PHONE],[MOBILE],[EMAIL],[SITE], [OTVETSTVENNIJ]) VALUES ('"+ID+"' , '"+ FullName+"' , '"+ SokrName+"', '"+INN+"', '"+KPP+"', '"+OGRN+"', '"+BankName+"', '"+BankBIK+"', '"+BankKS+"', '"+BankRS+"','"+RukDolzhn+"', '"+Vlice+"', '"+FIOruk+"', '"+UrAddr+"', '"+FaktAddr+"', '"+PostAddr+"', '"+Phone+"', '"+Mobile+"','"+Email+"','"+Site+"','"+Otvetstvennij+"'); ");
    }
    
    public void DelKontragent(String ID)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        
        db.execSQL("DELETE FROM KONTRAGENTI WHERE ID=" + ID+";");
    }
    
    public void ExportDB()
    {
    	 String inputPath="";
      String inputFile="";
      String outputPath="";
      copyFile(inputPath,inputFile,outputPath);
    }
    
    private void copyFile(String inputPath, String inputFile, String outputPath) {

        InputStream in = null;
        OutputStream out = null;
        try {

            //create output directory if it doesn't exist
            File dir = new File(outputPath);
            if (!dir.exists())
            {
                dir.mkdirs();
            }


            in = new FileInputStream(inputPath + inputFile);
            out = new FileOutputStream(outputPath + inputFile);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;

            // write the output file (You have now copied the file)
            out.flush();
            out.close();
            out = null;

        }  catch (FileNotFoundException fnfe1) {
            Log.e("copyerrortag", fnfe1.getMessage());
        }
        catch (Exception e) {
            Log.e("copyerrortag", e.getMessage());
        }

    }
    
    
}
