package ru.mastercond;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import android.view.View;
import android.view.WindowManager;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import ru.mastercond.R;
import ru.mastercond.MenuOpened;
import ru.mastercond.fragment_test;
import ru.mastercond.fragment_mainpage;
import ru.mastercond.fragment_add_kontragent;

import android.view.WindowManager;
import android.content.Context;
import android.content.ContentValues;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Arrays;

import android.util.Log;
import android.util.DisplayMetrics; 

import ru.mastercond.SQLiteConnect;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.SQLException;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;




public class MainActivity extends Activity {
  
  SQLiteConnect DB;
  
  FragmentTransaction fTrans;
  fragment_test frag1;
  fragment_mainpage fragmain;
  fragment_add_kontragent fragaddkontragent;
  


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    
    DB=new SQLiteConnect(this);
    
     //=================СЕКЦИЯ КОПИРОВАНИЯ ФАЙЛА БАЗЫ ДАННЫХ В КОРНЕВУЮ ПАПКУ SDCARD0=================
        Context CN = getApplicationContext();
        String dbfilePath= CN.getDatabasePath("db").getPath().toString(); //получить путь до dbbusinessmanagement1.db
        String dbfileOUTPath=Environment.getExternalStorageDirectory().getAbsolutePath().toString()+"/Управление.бизнесом/"; //получить путь до /storage/sdcard0 + НУЖНО android.permission.WRITE_EXTERNAL_STORAGE в MANIFEST!!!

        copyFile(dbfilePath,"businessmanagement.db",dbfileOUTPath); //скопировать файл базы данных для отладки
        
        

     //=================СЕКЦИЯ КОПИРОВАНИЯ ФАЙЛА БАЗЫ ДАННЫХ В КОРНЕВУЮ ПАПКУ SDCARD0=================
    
    
    final ImageButton menuButton = (ImageButton)findViewById(R.id.MenuButton);
    final ScrollView menuLayout=(ScrollView)findViewById(R.id.MenuLayout);
    final MenuOpened iMO=new MenuOpened();
    iMO.setMenuOpened(false);
    menuLayout.setVisibility(View.GONE);
    
    
    
    menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              
              boolean isMenuOpened=iMO.getMenuOpened();
      
               if (isMenuOpened==false) 
                {
                 menuLayout.setVisibility(View.VISIBLE);
                 iMO.setMenuOpened(true);
                } 
                
                if (isMenuOpened==true) 
                {
                 menuLayout.setVisibility(View.GONE);
                 iMO.setMenuOpened(false);
                } 

  }
 }) ;
 
 

    final Button FragmentButtonWorkTable = (Button)findViewById(R.id.MenuButton0);
    final Button FragmentButtonSdelki = (Button)findViewById(R.id.MenuButton1);
    final Button FragmentButtonKontragenti = (Button)findViewById(R.id.MenuButton2);
    final Button FragmentButtonMyOrgs = (Button)findViewById(R.id.MenuButton3);
    final Button FragmentButtonTovariUslugi = (Button)findViewById(R.id.MenuButton4);
    final Button FragmentButtonSotrudniki = (Button)findViewById(R.id.MenuButton5);
    final Button FragmentButtonMiniSklad = (Button)findViewById(R.id.MenuButton6);
    final Button FragmentButtonFinance = (Button)findViewById(R.id.MenuButton7);
    final Button FragmentButtonSajti = (Button)findViewById(R.id.MenuButton8);
    final Button FragmentButtonSync = (Button)findViewById(R.id.MenuButton9);
    final Button FragmentButtonSettings = (Button)findViewById(R.id.MenuButton10);
    
    final Button FragmentButtonWorkTableUP = (Button)findViewById(R.id.UPMenuButton0);
    final Button FragmentButtonAddSdelka = (Button)findViewById(R.id.UPMenuButton1);
    final Button FragmentButtonAddKontragent = (Button)findViewById(R.id.UPMenuButton2);
    final Button FragmentButtonAddMyOrg = (Button)findViewById(R.id.UPMenuButton3);
    final Button FragmentButtonAddTovarUsluga = (Button)findViewById(R.id.UPMenuButton4);
    final Button FragmentButtonAddDelo = (Button)findViewById(R.id.UPMenuButton5);
    final Button FragmentButtonAddZametka = (Button)findViewById(R.id.UPMenuButton6);
    final Button FragmentButtonAddSotrudnik = (Button)findViewById(R.id.UPMenuButton7);
    
    
    
    frag1=new fragment_test();
    fragmain=new fragment_mainpage();
    fragaddkontragent=new fragment_add_kontragent();
    
    
    fTrans = getFragmentManager().beginTransaction();
    fTrans.add(R.id.FragmentArea, fragmain);
    fTrans.commit();
    
    
    FragmentButtonWorkTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    fTrans = getFragmentManager().beginTransaction();
    fTrans.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).replace(R.id.FragmentArea, fragmain);
    fTrans.addToBackStack(null);
    fTrans.commit();             
    }
   });
    
   
   FragmentButtonSdelki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    fTrans = getFragmentManager().beginTransaction();
    fTrans.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).replace(R.id.FragmentArea, frag1);
    fTrans.addToBackStack(null);
    fTrans.commit();             
    }
   });
   
   
   
   
   
   FragmentButtonWorkTableUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    fTrans = getFragmentManager().beginTransaction();
    fTrans.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).replace(R.id.FragmentArea, fragmain);
    fTrans.addToBackStack(null);
    fTrans.commit();             
    }
   });
   
   FragmentButtonAddKontragent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    fTrans = getFragmentManager().beginTransaction();
    fTrans.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).replace(R.id.FragmentArea, fragaddkontragent);
    fTrans.addToBackStack(null);
    fTrans.commit();             
    }
   });
       
    
          
       
 } 


private void copyFile(String inputPath, String inputFile, String outputPath) {

        InputStream in = null;
        OutputStream out = null;
        try {

            //create output directory if it doesn't exist
            File dir = new File(outputPath);
            if (!dir.exists())
            {
                dir.mkdirs();
            }


            in = new FileInputStream(inputPath + inputFile);
            out = new FileOutputStream(outputPath + inputFile);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;

            // write the output file (You have now copied the file)
            out.flush();
            out.close();
            out = null;

        }  catch (FileNotFoundException fnfe1) {
            Toast.makeText(getApplicationContext(), fnfe1.toString(), Toast.LENGTH_LONG).show();
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }
    



} 
